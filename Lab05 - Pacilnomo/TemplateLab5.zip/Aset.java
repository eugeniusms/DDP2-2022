
public class Aset {
	// TODO lengkapi visibility modifier atribut dan methods berikut
	String nama;
	int jumlah;
	double harga;
	int tahun = 0;
	
	Aset(String nama, int jumlah, double harga) {
		// TODO lengkapi constructor ini
	}
	
	// Increment tahun
	void nextYear() {
	
	}

	// TODO buat getter dan setter untuk fields pada class ini
}
