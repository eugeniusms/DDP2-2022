// Main class untuk menjalankan program
public class Main {
    public static void main(String[] args) {
        // Melakukan konstruksi untuk frame
        new CurrencyConversionFrame();
    }
}
